#packages <- c("dplyr", "ISLR", "cluster", "Rtsne", "ggplot2")


#if (length(setdiff(packages, rownames(installed.packages()))) > 0) {
 # install.packages(setdiff(packages, rownames(installed.packages())))  
#}

#rm(packages)

library(dplyr) # for data cleaning
library(cluster) # for gower similarity and pam
library(Rtsne) # for t-SNE plot
library(ggplot2) # for visualization
setwd("D:\\VI SEM\\DWDM LAB\\Project\\Final Dataset")
grade_input = as.data.frame(read.csv("dataset.csv"))

#data <- read.csv("dataset.csv", sep = ";")
## creation of dissimilarity matrix using "Gower distance" for mixed data 
##types

gower_dist <- daisy(data,
                    metric = "gower",
                    type = list())
gower_mat <- as.matrix(gower_dist)
write.table(gower_mat, file = "dissimilarity.csv")
summary(gower_dist)


sil_width <- c(NA)
for(l in 2:8){
  pam_fit <- pam(gower_dist,
                 diss = TRUE,
                 k = l)
  
  sil_width[l] <- pam_fit$silinfo$avg.width
}

nclust <- which.max(sil_width) # identify index of highest value
opt.value <- max(sil_width, na.rm = TRUE) # identify highest value
ncluster <- round(mean(nclust))
valcluster <- max(opt.value)

## start PAM clustering with n clusters
pam_fit <- pam(gower_dist, diss = TRUE, k = ncluster)

pam_results <- data.sample %>%
  mutate(cluster = pam_fit$clustering) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))


#pam_results$the_summary

#data.sample[pam_fit$medoids, ]


tsne_obj <- Rtsne(gower_dist, is_distance = TRUE)
tsne_data <- tsne_obj$Y %>%
  data.frame() %>%
  setNames(c("X", "Y")) %>%
  mutate(cluster = factor(pam_fit$clustering))
ggplot(aes(x = X, y = Y), data = tsne_data) +
  geom_point(aes(color = cluster)) 