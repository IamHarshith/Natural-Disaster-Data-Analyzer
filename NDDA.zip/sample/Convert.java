package csv;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Convert {

	public static void main(String[] args) {
		//File f = new File(args[0]);
		//File o = new File(args[1]);
		//File of = new File(args[2]);
		
		
		
		File f = new File("Bali.csv");
		File o = new File("bali1.csv");
		//File of = new File("hshsh");
		
		
		
		
		String toReplace[]  = {"Sumbawa Region-Indonesia" ,"Northern Sumatra-Indonesia", "Seram-Indonesia",   
    "Java-Indonesia", "Banda Sea", "Minahassa Peninsula-Sulawesi", "North of Halmahera-Indonesia",
    "Sulawesi-Indonesia", "Tanimbar Islands Reg.-Indonesia", "Southern Sumatra-Indonesia",
    "Flores Region-Indonesia", "Halmahera-Indonesia", "Off West Coast of Northern Sumatra", 
    "South of Java-Indonesia", "Southwest of Sumatra-Indonesia", "Bali Region-Indonesia",
    "Timor Sea", "South of Bali-Indonesia", "Timor Region", "Buru-Indonesia",
    "Sumba Region-Indonesia", "Talaud Islands-Indonesia" };
		
		ArrayList<String> tr = new ArrayList<>();
		for(int i=0; i<toReplace.length; i++){
			tr.add(toReplace[i]);
		}
		
		String replacement[] = {"West Nusa Tenggara", "North Sumatra", "Maluku", "Java", "Maluku", "North Sulawesi", "Maluku",
		"South Sulawesi", "Maluku", "South Sumatra", "East Nusa Tenggara", "Maluku", "North Sumatra", "Java", "South Sumatra",
		"Bali", "East Nusa Tenggara", "Bali", "East Nusa Tenggara", "Maluku", "East Nusa Tenggara", "North Sulawesi"};
		
		ArrayList<String> r = new ArrayList<>();
		for(int i=0; i<replacement.length; i++){
			r.add(replacement[i]);
		}
		
		//ArrayList<String> places = new ArrayList<>();
		if(f.exists()){
			BufferedReader reader = null, otherReader = null;
			BufferedWriter writer = null;
			try {
				reader = new BufferedReader(new FileReader(f));
				if(!o.exists()){
					f.createNewFile();
				}
				writer = new BufferedWriter(new FileWriter(o));
				String line = reader.readLine();
				int count = 0, flag = 0;
				
				//Get specific column data
				//display unique region
				/*while(line!=null){
					count++;
					if(line.contains(",")){
						line = line.replace(", ", "-");
					}
					if(count == 13){
						count=0;
						if(!places.contains(line)){
							places.add(line);
							line = line + "\n";
							writer.write(line);
						}
						
					}else{
						line = line + ", ";
					}
					line = reader.readLine();
				}*/
				
				//Get all column data
				//text to csv
				/*while(line!=null){
					count++;
					if(line.contains(",")){
						line = line.replace(", ", "-");
					}
					if(count == 13){
						count=0;
						line = line + "\n";
						writer.write(line);
					}else{
						line = line + ", ";
						writer.write(line);
					}
					line = reader.readLine();
				}*/
				
				
				//Get required rows only
				/*String fLine = "";
				while(line!=null){
					count++;
					if(count == 13){
						count=0;
						if(tr.contains(line.trim())){
							line = r.get(tr.indexOf(line.trim())) + "\n";
							fLine += line;
							writer.write(fLine);
						}
						fLine = "";
					}else{
						fLine += (line + ", ");
					}
					line = reader.readLine();
				}*/
				
				//Replace outliers with missing values
				/*while(line!=null){
					String[] subs = line.split(",");
					for(int i=0; i<subs.length; i++){
						subs[i] = subs[i].trim();
					}
					
					for(int i=0; i<subs.length; i++){
						if(subs[i].startsWith("\"") && subs[i].endsWith("\"")){
							subs[i] = subs[i].substring(1, subs[i].length()-1);
						}
						
						if(subs[i].equals("8888.0") || subs[i].equals("9999.0") || subs[i].equals("8888") || subs[i].equals("9999")){
							subs[i] = " ";
						}
					}
					
					line = "";
					for(int i=0; i<subs.length; i++){
						if(i == subs.length - 1){
							line += (subs[i] + "\n");
						}else{
							line += (subs[i] + ", ");
						}
					}
					
					writer.write(line);
					line = reader.readLine();
				}*/
				
				//Merge two tables 
			/*	line = reader.readLine();
				line = reader.readLine();
				while(line != null){
					String[] split1 = line.split(",");
					for(int i=0; i<split1.length; i++){
						split1[i] = split1[i].trim();
					}
					
					otherReader = new BufferedReader(new FileReader(of));
					String iLine = otherReader.readLine();
					iLine = otherReader.readLine();
					while(iLine != null){
						String[] split2 = iLine.split(",");
						for(int i=0; i<split2.length; i++){
							split2[i] = split2[i].trim();
							if(i == 1){
								System.out.println(split2[i]);
								String[] split3 = split2[i].split("/");
								for(int k=0; k<split3.length; k++){
									System.out.println(split3[k]);
								}
								String temp = split3[2] + "-" + split3[1] + "-" + split3[0];
								split2[i] = temp;
							}
						}
						
						if(split1[0].equals(split2[1]) && split1[1].equals(split2[0])){
							String fLine = "";
							for(int i=0; i<split1.length; i++){
								fLine += (split1[i] + ", ");
							}
							
							for(int i=2; i<split2.length; i++){
								if(i == split2.length - 1){
									fLine += (split2[i] + "\n");
								}else{
									fLine += (split2[i] + ", ");
								}
							}
							writer.write(fLine);
						}
						
						iLine = otherReader.readLine();
					}
					
					otherReader.close();
					line = reader.readLine();
				}
				*/
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			} finally{
				try {
					reader.close();
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}else{
			System.out.println("File doesnt exist!");
		}
	}

}
