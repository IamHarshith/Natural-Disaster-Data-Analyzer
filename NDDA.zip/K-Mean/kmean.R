library(plyr)
library(ggplot2)
library(cluster)
library(lattice)
library(graphics)
library(grid)
library(gridExtra)

#reading the dataset
#D:\\VI SEM\\DWDM LAB\\Project\\Final Dataset\\dataset.csv
setwd("D:\\VI SEM\\DWDM LAB\\Project\\Final Dataset")
grade_input = as.data.frame(read.csv("dataset.csv"))

#all the columns are considered
kmdata_orig = as.matrix(grade_input[,c("a","b","c","d", "e","f","g","h","i","j","k","l","m")])

#since 1st and 2nd columns are date and place they are ignored and from 3rd to 13 it's considered
kmdata <- kmdata_orig[,3:13]

#taking 1st 10rows
kmdata[1:10,]

#getting the cluster value
wss <- numeric(5)
for (k in 1:5) wss[k] <- sum(kmeans(kmdata, centers=k, nstart=25)$withinss)

#since the values are very big(out of range) divide it by 1000 to get the cluster value
for (t in 1:5)new[t]=wss[t]/1000

new

#plot to see the change i.e the value where it becomes constant
plot(1:5, wss, type="b", xlab="Number of Clusters", ylab="Within Sum of Squares")

plot(1:5, wss, type="b", xlab="Number of Clusters", ylab="Within Sum of
Squares")


#getting k-means
km = kmeans(kmdata,5, nstart=25)
km

c( wss[5] , sum(km$withinss) )

df = as.data.frame(kmdata_orig[,3:13])

df$cluster = factor(km$cluster)
centers=as.data.frame(km$centers)
centers
